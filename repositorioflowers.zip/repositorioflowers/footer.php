<footer class="page-footer font-small teal pt-4">
    <div class="container-fluid" id="foot">
        <img src="img/SVG/logo_utcgg.svg">
</footer>   